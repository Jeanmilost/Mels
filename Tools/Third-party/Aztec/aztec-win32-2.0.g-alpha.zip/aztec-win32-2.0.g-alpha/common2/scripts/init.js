// This is the script that is loaded upon startup of Aztec.
// In here goes any initalisation, extra information, or loading of
// any other additional scripts.

print('Loading init.js...\n');

load('gear.js');

load('createObject.js');
load('groupSelectedObjects.js');

//load('testgui.js');

print('Finished loading init.js\n');