function sliderOnChange(slider, output) {

  var text = "Slider Change: " + slider.value;
  output.value = text;

}

function sliderExample() {

  var mainWindow = new MWindow();
  mainWindow.setLayoutManager(new MBorderLayout());

  var output = new MTextField("Move the slider around");
  mainWindow.addComponent(output, MBorderLayout.NORTH);

  var slider = new MSlider(0, 10, 5);

  mainWindow.addComponent(slider, MBorderLayout.SOUTH);

  slider.addListener(sliderOnChange, slider, output);
  slider.setMinimumSize(300,0);

  mainWindow.setSize(300,100);
  mainWindow.setVisible(true);	

}

sliderExample();