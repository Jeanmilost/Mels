function checkboxOnChange(checkbox, output) {

  var text = "Checkbox Change: " + checkbox.getValue();
  output.setValue(text);

}

function checkboxExample() {

  var mainWindow = new MWindow();
  mainWindow.setLayoutManager(new MBorderLayout());

  var output = new MTextField("Click the checkbox around");
  mainWindow.addComponent(output, MBorderLayout.NORTH);

  var checkbox = new MCheckbox();

  mainWindow.addComponent(checkbox, MBorderLayout.SOUTH);

  checkbox.addListener(checkboxOnChange, checkbox, output);

  mainWindow.setSize(300,100);
  mainWindow.setVisible(true);	

}

checkboxExample();