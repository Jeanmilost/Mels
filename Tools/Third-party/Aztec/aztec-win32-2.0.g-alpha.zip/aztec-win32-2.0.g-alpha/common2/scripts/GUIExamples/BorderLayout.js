function createExampleComponent(window, caption, placement, r, g, b) {
  var container = new MContainer();
  container.setBackgroundColour(r, g, b);
  container.setMinimumSize(64, 64);
  container.setLayoutManager(new MBorderLayout(5, 5));
  window.addComponent(container, placement);

  container.addComponent(new MButton(caption));
}

function borderLayoutExample() {

  var mainWindow = new MWindow();
  mainWindow.setLayoutManager(new MBorderLayout());

  createExampleComponent(mainWindow, "West", MBorderLayout.WEST, 1.0, 0.0, 0.0);
  createExampleComponent(mainWindow, "East", MBorderLayout.EAST, 0.0, 1.0, 0.0);
  createExampleComponent(mainWindow, "North", MBorderLayout.NORTH, 1.0, 0.0, 1.0);
  createExampleComponent(mainWindow, "South", MBorderLayout.SOUTH, 1.0, 1.0, 0.0);
  createExampleComponent(mainWindow, "Inner North", MBorderLayout.NORTH_INNER, 0.0, 1.0, 1.0);
  createExampleComponent(mainWindow, "Inner South", MBorderLayout.SOUTH_INNER, 1.0, 0.0, 1.0);
  createExampleComponent(mainWindow, "Centre", MBorderLayout.CENTRE, 0.0, 0.0, 0.0);

  mainWindow.setSize(mainWindow.getMinimumSize());
  mainWindow.setVisible(true);	

}

borderLayoutExample();