function createItem(container, caption) {
  var label = new MLabel(caption);
  var editBox = new MTextField();

  container.addComponent(label);
  container.addComponent(editBox);
}

function textLabelsExample() {

  var mainWindow = new MWindow();
  // the flow layout takes three args, the x and y margins, 
  // and then the number of components per row
  mainWindow.setLayoutManager(new MFlowLayout(2,2,2));

  createItem(mainWindow, "Label 1");
  createItem(mainWindow, "Label 2");
  createItem(mainWindow, "Label 3");

  mainWindow.setVisible(true);	

}

textLabelsExample();