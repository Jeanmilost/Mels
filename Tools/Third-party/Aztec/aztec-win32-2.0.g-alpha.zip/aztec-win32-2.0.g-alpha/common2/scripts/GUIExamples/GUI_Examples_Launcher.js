
function onClick() {
  eval(this.getCommand());
}

function addExample(window, caption, command) {
  var button = new MButton(caption, command);
  button.addListener(onClick);

  window.addComponent(button, MBorderLayout.CENTRE);
}

function exampleLauncher() {

  var window = new MWindow("GUI Example Scripts");

  // Create a flow layout that has a border of (2,2) pixels and 
  // only allows 1 component per row.
  window.setLayoutManager(new MFlowLayout(2,2,1));
//  window.setLayoutManager(new MBorderLayout());

  // Create some buttons to launch each of our demos
  addExample(window, "Border Layout Example", "load('GUIExamples/BorderLayout.js');");
  addExample(window, "Mouse Event Example", "load('GUIExamples/MouseEvent.js');");
  addExample(window, "Resizing Example", "load('GUIExamples/Resizing.js');");
  addExample(window, "Keyboard Event Example", "load('GUIExamples/KeyEvent.js');");
  addExample(window, "Slider Example", "load('GUIExamples/Slider.js');");
  addExample(window, "CheckBox Example", "load('GUIExamples/Checkbox.js');");
  addExample(window, "Labels Example", "load('GUIExamples/TextLabels.js');");
  addExample(window, "Scrolled Container", "load('GUIExamples/ScrolledContainer.js');");
  addExample(window, "Text Fields", "load('GUIExamples/TextFields.js');");
  addExample(window, "Combo Boxes", "load('GUIExamples/ComboBoxes.js');");
  addExample(window, "Tabbed Container", "load('GUIExamples/TabbedContainer.js');");

  window.setSize(window.getMinimumSize());

  window.setVisible(true);	
}

exampleLauncher();