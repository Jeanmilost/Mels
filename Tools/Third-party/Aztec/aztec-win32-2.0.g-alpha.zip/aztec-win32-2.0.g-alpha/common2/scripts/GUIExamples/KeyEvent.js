function onKeyEvent(event, output) {

//  var text = "Key Event: " + event.type + " " + MKeyEvent.keyCodeToStr(event.code) + " " + event.char;
  var text = "Key Event: " + event.type + " " + MKeyEvent.keyCodeToStr(event.code) + " " + event.ascii;

  output.setValue(text);

}

function mouseEventExample() {

  var mainWindow = new MWindow();
  mainWindow.setLayoutManager(new MBorderLayout());

  var input = new MTextField("Type in here...");
  mainWindow.addComponent(input, MBorderLayout.NORTH);

  var output = new MTextField("Output goes here...");
  mainWindow.addComponent(output, MBorderLayout.SOUTH);

  input.addKeyListener(onKeyEvent, output);

  mainWindow.setSize(300,100);
  mainWindow.setVisible(true);	

}

mouseEventExample();