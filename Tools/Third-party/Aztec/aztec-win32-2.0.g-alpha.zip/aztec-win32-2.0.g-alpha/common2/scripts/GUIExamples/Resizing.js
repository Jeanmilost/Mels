function createExampleComponent(window, caption, placement, r, g, b, event, x, y) {
  var container = new MContainer();
  container.setBackgroundColour(r, g, b);
  container.setMinimumSize(64, 64);
  container.setLayoutManager(new MBorderLayout(5, 5));
  window.addComponent(container, placement);

  var button = new MButton(caption);
  button.addListener(event, window, x, y);
  container.addComponent(button);
}

function makeBigger(window, x, y) {
  var size = window.getSize();
  size.x2 += x;
  size.y2 += y;
  window.setSize(size);
}

function resizingExample() {

  var mainWindow = new MWindow();
  mainWindow.setLayoutManager(new MBorderLayout());

  createExampleComponent(mainWindow, "West", MBorderLayout.WEST, 1.0, 0.0, 0.0, makeBigger, -20, 0);
  createExampleComponent(mainWindow, "East", MBorderLayout.EAST, 0.0, 1.0, 0.0, makeBigger, 20, 0);
  createExampleComponent(mainWindow, "North", MBorderLayout.NORTH, 1.0, 0.0, 1.0, makeBigger, 0, -20);
  createExampleComponent(mainWindow, "South", MBorderLayout.SOUTH, 1.0, 1.0, 0.0, makeBigger, 0, 20);

  mainWindow.setSize(300,300);

  mainWindow.setSize(mainWindow.getMinimumSize());
  mainWindow.setVisible(true);	

}

resizingExample();