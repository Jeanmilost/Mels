function mouseMove(event, button, reporter) {
  reporter.setCaption("onMouseMove (" + button.getCaption() + " : " + event.x + ", " + event.y + ")");
}

function buttonClick(reporter) {
  this.setCaption("click this.setCap");
  reporter.setCaption("buttonClicked (" + this.getCaption() + ")");
}

function createStuff(window, reporter, caption, placement, r, g, b) {
  var cont = new MContainer();
  cont.setBackgroundColour(r, g, b);
  cont.setMinimumSize(64, 64);
  cont.setLayoutManager(new MBorderLayout(5, 5));
  window.addComponent(cont, placement);

  var button = new MButton("test cap");
  cont.addComponent(button);

  button.setCaption(caption);
  button.addListener(buttonClick, reporter);

  cont.addMouseListener(mouseMove, button, reporter);
}

var win = new MWindow();
win.setLayoutManager(new MBorderLayout());

var container = new MContainer();
container.setLayoutManager(new MBorderLayout());

win.addComponent(container, MBorderLayout.CENTRE);

var reporter = new MButton("Text goes Here");
win.addComponent(reporter, MBorderLayout.SOUTH);

createStuff(container, reporter, "West", MBorderLayout.WEST, 1.0, 0.0, 0.0);
createStuff(container, reporter, "East", MBorderLayout.EAST, 0.0, 1.0, 0.0);
createStuff(container, reporter, "North", MBorderLayout.NORTH, 1.0, 0.0, 1.0);
createStuff(container, reporter, "South", MBorderLayout.SOUTH, 1.0, 1.0, 0.0);
createStuff(container, reporter, "Inner North", MBorderLayout.NORTH_INNER, 0.0, 1.0, 1.0);
createStuff(container, reporter, "Inner South", MBorderLayout.SOUTH_INNER, 1.0, 0.0, 1.0);
createStuff(container, reporter, "Centre", MBorderLayout.CENTRE, 0.0, 0.0, 0.0);

win.setVisible(true);	